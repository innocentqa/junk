from flask import Flask,request, make_response, render_template
from app import app
from functools import wraps

ALL_HTTP_METHODS    = ['GET', 'HEAD', 'POST', 'PUT', 'DELETE', 'CONNECT', 'OPTIONS', 'TRACE', 'PATCH']
COMMON_HTTP_METHODS = ['GET','PUT','POST','DELETE']
BASIC_AUTH_USERNAME = 'diyuser'
BASIC_AUTH_PASSWORD = 'diypwd'
MSG_AUTH_INVALID_OR_NOTPROVIDED = "No or invalid basic auth param"


def my_auth_required(f):
    @wraps(f)
    def my_auth_decorators(*args, **kwargs):
        my_auth = request.authorization
        if my_auth and my_auth.username==BASIC_AUTH_USERNAME and my_auth.password==BASIC_AUTH_PASSWORD:
            return f(*args, **kwargs)
        else:
            return make_response(MSG_AUTH_INVALID_OR_NOTPROVIDED, 401, {'WWW-Authenticate' : 'Basic realm="No or invalid basic auth param provided"  '  } )
        
    return my_auth_decorators    



####################################################################################
# version 0 - base endpoint      / or /home
####################################################################################
@app.route('/',     methods=ALL_HTTP_METHODS)
@app.route('/home', methods=ALL_HTTP_METHODS)
def home():
    if request.method in COMMON_HTTP_METHODS:
        return render_template('documentation.html')
    else :
        return "You are an alien! Go back to your place !"




####################################################################################
# versio 1 - basic enpoints
####################################################################################

@app.route('/v1/register', methods=ALL_HTTP_METHODS)
def v1_register():
    if request.method != 'POST':
        return "POST method to be used"
    #user = request.args.get('user', default = "", type = str)
    #pwd  = request.args.get('pwd',  default = "", type = str)
    #print (user)
    #print (pwd)
    inputjson = request.json
    print (request.get_json(force=True))
    print (request.get_json(force=True)["user"])
    #if not user or not pwd:
    #    return "invalid username or pwd"
    return "registration success"




@app.route('/auth_check')
@my_auth_required
def auth_check():
    return "auth is tested"


@app.route('/auth_check_again')
@my_auth_required
def auth_check_again():
    return "auth is tested again"



@app.route('/search', methods=['GET'])
def search_url_parameters():
    print(' search_item=' , request.args.get('search_item', default = '---', type = str)  )
    print(' search_item_qty=' , request.args.get('search_item_qty', default = 1, type = int)   )
    return "search was called "

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'GET':
        print ('/login api called GET')
    if request.method == 'POST':
        print ('/login api called POST')
    return "/login api called123"

@app.route('/v2/check', methods=['GET', 'POST'])
def v2_check():
    if request.method == 'GET':
        print ('/v2/check api called GET')
    if request.method == 'POST':
        print ('/v2/check api called POST')
    return "/v2/check api called123"


@app.route('/favicon.ico') 
def favicon(): 
    return ""


if __name__ == '__main__':
    app.run()

