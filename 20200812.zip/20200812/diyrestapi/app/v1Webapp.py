from flask import Flask,request, make_response, render_template, jsonify, make_response
from app import app
from functools import wraps
import json
from app.helperGeneral import *

MIN_LEN_USERNAME = 8
MIN_LEN_PASSWORD = 8
MAX_USER_COUNT   = 16
LATEST_USER_ID   = 0
dict_alluser     = {}


def v1ProcessRegistration(req):
    global LATEST_USER_ID
    print (str(req.get_json(force=True)))
    input_json = None
    flag_invalid_json = False
    
    # check if input json is valid
    try:
        input_json = req.get_json(force=True)
        if len(input_json["user"]) <= MIN_LEN_USERNAME or len(input_json["password"]) <= MIN_LEN_PASSWORD or "@" not in input_json["user"] :
            flag_invalid_json = True
    except:
        flag_invalid_json = True
    
    if flag_invalid_json:
        return make_response(jsonify(message= "Invalid input json"), 400)
        
    # check if user already exists
    userexists = False
    for oneuserdata in dict_alluser.values():
        for oneuserkey, oneuservalue in oneuserdata.items():
            if oneuserkey == "user" and oneuservalue == input_json["user"] :
                userexists = True
                break

    if userexists :
        return make_response(jsonify(message= "Duplicate user"), 400)

    # it is a fresh user, so get latest userid
    for n in range(0, MAX_USER_COUNT):
       if LATEST_USER_ID == MAX_USER_COUNT:
           print ("Max user count reached. Resetting to zero")
           LATEST_USER_ID = 0
    LATEST_USER_ID+=1
    useridcurrent="userid_"+str(format(-1 + LATEST_USER_ID, '02d'))
    # prepare default values for fresh user
    input_json["loginstatus"]=False
    input_json["token"]=""
    # add user to dictionary
    dict_alluser[useridcurrent]=input_json

    print ("Registration success, userid=",useridcurrent)
    return make_response(jsonify(register = "Registration success", userid=useridcurrent), 201)





def v1ProcessLogin(req):
    print (str(req.get_json(force=True)))
    input_json = None
    flag_invalid_json = False
    
    # check if input json is valid
    try:
        input_json = req.get_json(force=True)
        if len(input_json["user"]) <= MIN_LEN_USERNAME or len(input_json["password"]) <= MIN_LEN_PASSWORD or "@" not in input_json["user"] :
            flag_invalid_json = True
    except:
        flag_invalid_json = True
    
    if flag_invalid_json:
        return make_response(jsonify(message= "Invalid input json"), 400)
        
    userexists = False
    falseloggedin = False
    freshtoken = getFreshToken()
    for oneuserdata in dict_alluser.values():
        if oneuserdata["user"] == input_json["user"] and oneuserdata["password"] == input_json["password"]:
            userexists = True
            # check if user has already logged in
            if oneuserdata["loginstatus"] :
                falseloggedin=True
            else:
                # it is existing user, not yet logged in, so update loginstatus and token
                oneuserdata["loginstatus"]=True
                oneuserdata["token"]=freshtoken
            break

    if not userexists :
        return make_response(jsonify(message= "User does not exist or password mismatch"), 400)
    if falseloggedin :
        return make_response(jsonify(message= "User already logged in"), 200)

    print ("Login success, token=",freshtoken)
    return make_response(jsonify(login = "Login success", token=freshtoken), 200)





def v1ChangePassword(req):
    print (str(req.get_json(force=True)))
    input_json = None
    flag_invalid_json = False
    
    # check if input json is valid
    try:
        input_json = req.get_json(force=True)
        if len(input_json["user"]) <= MIN_LEN_USERNAME or len(input_json["password"]) <= MIN_LEN_PASSWORD or len(input_json["newpassword"]) <= MIN_LEN_PASSWORD or "@" not in input_json["user"] :
            flag_invalid_json = True
    except:
        flag_invalid_json = True
    
    if flag_invalid_json:
        return make_response(jsonify(message= "Invalid input json"), 400)

    userexists = False
    loggedinstatus = False
    for oneuserdata in dict_alluser.values():
        if oneuserdata["user"] == input_json["user"] and oneuserdata["password"] == input_json["password"]:
            userexists = True
            # check if user has already logged in
            if oneuserdata["loginstatus"] :
                # it is existing user, already logged in, so update password
                oneuserdata["password"]=input_json["newpassword"]
                loggedinstatus = True
            break

    if not userexists :
        return make_response(jsonify(message= "User does not exist or password mismatch"), 400)
    if not loggedinstatus :
        return make_response(jsonify(message= "To change password user needs to log in first"), 400)

    print ("Change password success")
    return make_response(jsonify(changepassword = "Change password success"), 200)






def v1ProcessLogout(req):
    print (str(req.get_json(force=True)))
    input_json = None
    flag_invalid_json = False
    
    # check if input json is valid
    try:
        input_json = req.get_json(force=True)
        if len(input_json["user"]) <= MIN_LEN_USERNAME or len(input_json["password"]) <= MIN_LEN_PASSWORD or "@" not in input_json["user"] :
            flag_invalid_json = True
    except:
        flag_invalid_json = True
    
    if flag_invalid_json:
        return make_response(jsonify(message= "Invalid input json"), 400)
        
    userexists = False
    falselogout = False
    for oneuserdata in dict_alluser.values():
        if oneuserdata["user"] == input_json["user"] and oneuserdata["password"] == input_json["password"]:
            userexists = True
            # check if user has already logged in
            if oneuserdata["loginstatus"] :
                loggedinstatus = True
                # it is existing user, already logged in, so logout and update loginstatus and token
                oneuserdata["loginstatus"]=False
                oneuserdata["token"]=""
            else:
                falselogout = True
            break

    if not userexists :
        return make_response(jsonify(message= "User does not exist or password mismatch"), 400)
    if falselogout :
        return make_response(jsonify(message= "User did not logged in so can not logout"), 400)

    print ("Logout success")
    return make_response(jsonify(logout = "Logout success"), 200)




