from flask import Flask,request, make_response, render_template, jsonify, make_response
from app import app
from functools import wraps
import json
from app.helperGeneral import *
import re
import datetime


MIN_USERNAME_LEN = 8
MAX_USERNAME_LEN = 16
MIN_PASSWORD_LEN = 8
MAX_PASSWORD_LEN = 16
MIN_ATTR_LEN     = 2
MAX_ATTR_LEN     = 16
MAX_USER_COUNT   = 16
LATESTUSERID     = 0
dictalluser      = {}
regex = re.compile('[@_!#$%^&*()<>?/\|}{~:_ -]')

def v2ProcessRegistration(req):
    global LATESTUSERID
    print (str(req.get_json(force=True)))
    input_json = None
    flag_invalid_json = False
    
    # check if input json is valid
    try:
        input_json = req.get_json(force=True)
        if len(input_json.keys()) != 5 :
            flag_invalid_json = True
        if len(input_json["user"]) < MIN_USERNAME_LEN or len(input_json["user"]) > MAX_USERNAME_LEN:
            flag_invalid_json = True
        if input_json["user"].startswith("@") or input_json["user"].endswith("@") or "." not in input_json["user"] :
            flag_invalid_json = True
        if len(input_json["password"]) < MIN_PASSWORD_LEN or len(input_json["password"]) > MAX_PASSWORD_LEN:
            flag_invalid_json = True
        if regex.search(input_json["firstname"]) != None or any(chr.isdigit() for chr in input_json["firstname"]) :
            flag_invalid_json = True
        if len(input_json["firstname"]) < MIN_ATTR_LEN or len(input_json["firstname"]) > MAX_ATTR_LEN:
            flag_invalid_json = True
        if regex.search(input_json["lastname"])  != None or any(chr.isdigit() for chr in input_json["lastname"]) :
            flag_invalid_json = True
        if len(input_json["lastname"]) < MIN_ATTR_LEN or len(input_json["lastname"]) > MAX_ATTR_LEN:
            flag_invalid_json = True
        if input_json["captcha"] != str(datetime.datetime.now().year) :
            flag_invalid_json = True
    except:
        flag_invalid_json = True
    
    if flag_invalid_json:
        return make_response(jsonify(message= "Invalid input json"), 400)
        
    # check if user already exists
    userexists = False
    for oneuserdata in dictalluser.values():
        for oneuserkey, oneuservalue in oneuserdata.items():
            if oneuserkey == "user" and oneuservalue == input_json["user"] :
                userexists = True
                break

    if userexists :
        return make_response(jsonify(message= "Duplicate user"), 400)

    # it is a fresh user, so get latest userid
    for n in range(0, MAX_USER_COUNT):
       if LATESTUSERID == MAX_USER_COUNT:
           print ("Max user count reached. Resetting to zero")
           LATESTUSERID = 0
    LATESTUSERID+=1
    useridcurrent="userid_"+str(format(-1 + LATESTUSERID, '02d'))
    # prepare default values for fresh user
    input_json["loginstatus"]=False
    input_json["token"]=""
    input_json["userid"]=useridcurrent
    # add user to dictionary
    dictalluser[useridcurrent]=input_json

    print ("Registration success, userid=",useridcurrent)
    return make_response(jsonify(register = "Registration success", userid=useridcurrent), 201)





def v2ProcessLogin(req):
    print (str(req.get_json(force=True)))
    input_json = None
    flag_invalid_json = False
    
    # check if input json is valid
    try:
        input_json = req.get_json(force=True)
        if len(input_json.keys()) != 2 :
            flag_invalid_json = True
        if len(input_json["user"]) < MIN_USERNAME_LEN or len(input_json["user"]) > MAX_USERNAME_LEN:
            flag_invalid_json = True
        if len(input_json["password"]) < MIN_PASSWORD_LEN or len(input_json["password"]) > MAX_PASSWORD_LEN:
            flag_invalid_json = True
    except:
        flag_invalid_json = True
    
    if flag_invalid_json:
        return make_response(jsonify(message= "Invalid input json"), 400)
        
    userexists = False
    falseloggedin = False
    freshtoken = getFreshToken()
    for oneuserdata in dictalluser.values():
        if oneuserdata["user"] == input_json["user"] and oneuserdata["password"] == input_json["password"]:
            userexists = True
            # check if user has already logged in
            if oneuserdata["loginstatus"] :
                falseloggedin=True
            else:
                # it is existing user, not yet logged in, so update loginstatus and token
                oneuserdata["loginstatus"]=True
                oneuserdata["token"]=freshtoken
            break

    if not userexists :
        return make_response(jsonify(message= "User does not exist or password mismatch"), 400)
    if falseloggedin :
        return make_response(jsonify(message= "User already logged in"), 200)

    print ("Login success, token=",freshtoken)
    return make_response(jsonify(login = "Login success", token=freshtoken), 200)




def v2ProcessUpdateprofile(req):
    print (str(req.get_json(force=True)))
    input_json = None
    flag_invalid_json = False
    
    # check if input json is valid
    try:
        input_json = req.get_json(force=True)
        if len(input_json.keys()) <= 2 or len(input_json.keys()) > 5 :
            flag_invalid_json = True
        if len(input_json["user"]) < MIN_USERNAME_LEN or len(input_json["user"]) > MAX_USERNAME_LEN:
            flag_invalid_json = True
        if len(input_json["password"]) < MIN_PASSWORD_LEN or len(input_json["password"]) > MAX_PASSWORD_LEN:
            flag_invalid_json = True
        if "firstname" in input_json :
            if regex.search(input_json["firstname"]) != None or any(chr.isdigit() for chr in input_json["firstname"]) :
                flag_invalid_json = True
            if len(input_json["firstname"]) < MIN_ATTR_LEN or len(input_json["firstname"]) > MAX_ATTR_LEN:
                flag_invalid_json = True
        if "lastname" in input_json:
            if regex.search(input_json["lastname"])  != None or any(chr.isdigit() for chr in input_json["lastname"]) :
                flag_invalid_json = True
            if len(input_json["lastname"]) < MIN_ATTR_LEN or len(input_json["lastname"]) > MAX_ATTR_LEN:
                flag_invalid_json = True
        if "newpassword" not in input_json:
            flag_invalid_json = True
    except:
        flag_invalid_json = True
    
    if flag_invalid_json:
        return make_response(jsonify(message= "Invalid input json"), 400)

    userexists = False
    loggedinstatus = False
    for oneuserdata in dictalluser.values():
        if oneuserdata["user"] == input_json["user"] and oneuserdata["password"] == input_json["password"]:
            userexists = True
            # check if user has already logged in
            if oneuserdata["loginstatus"] :
                # it is existing user, already logged in, so update password
                oneuserdata["password"]=input_json["newpassword"]
                if "firstname" in input_json:
                    oneuserdata["firstname"]=input_json["firstname"]
                if "lastname" in input_json:
                    oneuserdata["lastname"]=input_json["lastname"]
                loggedinstatus = True
            break

    if not userexists :
        return make_response(jsonify(message= "User does not exist or password mismatch"), 400)
    if not loggedinstatus :
        return make_response(jsonify(message= "To update profile user needs to log in first"), 400)

    print ("Change password success")
    return make_response(jsonify(changepassword = "Update profile success"), 200)







def v2ProcessLogout(req):
    print (str(req.get_json(force=True)))
    input_json = None
    flag_invalid_json = False
    
    # check if input json is valid
    try:
        input_json = req.get_json(force=True)
        if len(input_json.keys()) != 2 :
            flag_invalid_json = True
        if len(input_json["user"]) < MIN_USERNAME_LEN or len(input_json["user"]) > MAX_USERNAME_LEN:
            flag_invalid_json = True
        if len(input_json["password"]) < MIN_PASSWORD_LEN or len(input_json["password"]) > MAX_PASSWORD_LEN:
            flag_invalid_json = True
    except:
        flag_invalid_json = True
    
    if flag_invalid_json:
        return make_response(jsonify(message= "Invalid input json"), 400)
        
    userexists = False
    falselogout = False
    for oneuserdata in dictalluser.values():
        if oneuserdata["user"] == input_json["user"] and oneuserdata["password"] == input_json["password"]:
            userexists = True
            # check if user has already logged in
            if oneuserdata["loginstatus"] :
                # it is existing user, already logged in, so logout and update loginstatus and token
                oneuserdata["loginstatus"]=False
                oneuserdata["token"]=""
            else:
                falselogout = True
            break

    if not userexists :
        return make_response(jsonify(message= "User does not exist or password mismatch"), 400)
    if falselogout :
        return make_response(jsonify(message= "User did not logged in so can not logout"), 400)

    print ("Logout success")
    return make_response(jsonify(logout = "Logout success"), 200)




def v2ProcessGetaccount(req):
    flag_invalid_params = False
    user = None
    password = None

    # check if input json is valid
    try:
        user     = request.args.get('user',     default = None, type = str)
        password = request.args.get('password', default = None, type = str)
        if not user or not password :
            flag_invalid_params = True
    except:
        flag_invalid_params = True
    
    if flag_invalid_params:
        return make_response(jsonify(message= "Invalid input params in get request"), 400)
        
    userexists = False
    output_json = None
    for oneuserdata in dictalluser.values():
        if oneuserdata["user"] == user and oneuserdata["password"] == password:
            userexists = True
            output_json = oneuserdata
            break

    if not userexists :
        return make_response(jsonify(message= "User does not exist or password mismatch"), 400)

    print ("Getaccount success ",output_json)
    return make_response(jsonify(getaccount = "Getaccount success", account=output_json), 200)


