from flask import Flask,request, make_response, render_template, jsonify, make_response
from app import app
from functools import wraps
from app.helper_1 import file_ops
from app.helper_2 import file_check
from app.v1Webapp import *
from app.v2Webapp import *

ALL_HTTP_METHODS    = ['GET', 'HEAD', 'POST', 'PUT', 'DELETE', 'CONNECT', 'OPTIONS', 'TRACE', 'PATCH']
COMMON_HTTP_METHODS = ['GET','PUT','POST','DELETE']
BASIC_AUTH_USERNAME = 'diyuser'
BASIC_AUTH_PASSWORD = 'diypwd'
MSG_AUTH_INVALID_OR_NOTPROVIDED = "No or invalid basic auth param"
RESPONSE_ALIEN      = "Only alien uses _METHOD_ method ! Go back to your place !"

def my_auth_required(f):
    @wraps(f)
    def my_auth_decorators(*args, **kwargs):
        my_auth = request.authorization
        if my_auth and my_auth.username==BASIC_AUTH_USERNAME and my_auth.password==BASIC_AUTH_PASSWORD:
            return f(*args, **kwargs)
        else:
            return make_response(MSG_AUTH_INVALID_OR_NOTPROVIDED, 401, {'WWW-Authenticate' : 'Basic realm="No or invalid basic auth param provided"  '  } )
        
    return my_auth_decorators    



####################################################################################
# version 0 - base api
####################################################################################
@app.route('/',     methods=ALL_HTTP_METHODS)
@app.route('/home', methods=ALL_HTTP_METHODS)
def home():
    if request.method in COMMON_HTTP_METHODS:
        return make_response(render_template('documentation.html'), 200)
    else :
        return make_response(jsonify(message=RESPONSE_ALIEN.replace("_METHOD_", request.method )), 400)


@app.route('/favicon.ico') 
def favicon(): 
    return ("",200)


####################################################################################
# version 1 - basic apis
####################################################################################

@app.route('/v1/register', methods=ALL_HTTP_METHODS)
def v1_register():
    if request.method != 'POST':
        return make_response(jsonify(message=RESPONSE_ALIEN.replace("_METHOD_", request.method )), 400)
    return v1ProcessRegistration(request)


@app.route('/v1/login', methods=ALL_HTTP_METHODS)
def v1_login():
    if request.method != 'POST':
        return make_response(jsonify(message=RESPONSE_ALIEN.replace("_METHOD_", request.method )), 400)
    return v1ProcessLogin(request)


@app.route('/v1/changepassword', methods=ALL_HTTP_METHODS)
def v1_changepassword():
    if request.method != 'PUT':
        return make_response(jsonify(message=RESPONSE_ALIEN.replace("_METHOD_", request.method )), 400)
    return v1ChangePassword(request)


@app.route('/v1/logout', methods=ALL_HTTP_METHODS)
def v1_logout():
    if request.method != 'POST':
        return make_response(jsonify(message=RESPONSE_ALIEN.replace("_METHOD_", request.method )), 400)
    return v1ProcessLogout(request)




####################################################################################
# version 2 - advanced apis
####################################################################################

@app.route('/v2/register', methods=ALL_HTTP_METHODS)
@my_auth_required
def v2_register():
    if request.method != 'POST':
        return make_response(jsonify(message=RESPONSE_ALIEN.replace("_METHOD_", request.method )), 400)
    return v2ProcessRegistration(request)


@app.route('/v2/login', methods=ALL_HTTP_METHODS)
@my_auth_required
def v2_login():
    if request.method != 'POST':
        return make_response(jsonify(message=RESPONSE_ALIEN.replace("_METHOD_", request.method )), 400)
    return v2ProcessLogin(request)


@app.route('/v2/updateprofile', methods=ALL_HTTP_METHODS)
@my_auth_required
def v2_updateprofile():
    if request.method != 'PUT':
        return make_response(jsonify(message=RESPONSE_ALIEN.replace("_METHOD_", request.method )), 400)
    return v2ProcessUpdateprofile(request)


@app.route('/v2/logout', methods=ALL_HTTP_METHODS)
@my_auth_required
def v2_logout():
    if request.method != 'POST':
        return make_response(jsonify(message=RESPONSE_ALIEN.replace("_METHOD_", request.method )), 400)
    return v2ProcessLogout(request)


@app.route('/v2/getaccount', methods=ALL_HTTP_METHODS)
@my_auth_required
def v2_getaccount():
    if request.method != 'GET':
        return make_response(jsonify(message=RESPONSE_ALIEN.replace("_METHOD_", request.method )), 400)
    return v2ProcessGetaccount(request)






if __name__ == '__main__':
    app.run()

