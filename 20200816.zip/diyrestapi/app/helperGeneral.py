from random import choice
from string import ascii_lowercase

def getFreshToken():
    return ''.join(choice(ascii_lowercase) for i in range(16))

