from flask import Flask,request, make_response, render_template, jsonify, make_response
from app import app
from functools import wraps
import json
from app.helperGeneral import *
import re
import datetime
import psycopg2

MIN_USERNAME_LEN = 8
MAX_USERNAME_LEN = 16
MIN_PASSWORD_LEN = 8
MAX_PASSWORD_LEN = 16
MIN_ATTR_LEN     = 2
MAX_ATTR_LEN     = 16
LATESTUSERID     = 0
dictalluser      = {}
regex            = re.compile('[@_!#$%^&*()<>?/\|}{~:_ -]')
db_username      ="postgres"
db_pwd           ="postgres"
db_host          ="127.0.0.1"
db_port          ="5432"
db_name          ="userdb"
tbl_name         ="account"


def v3ProcessRegistration(req):
    global LATESTUSERID
    print (str(req.get_json(force=True)))
    input_json = None
    flag_invalid_json = False
    
    # check if input json is valid
    try:
        input_json = req.get_json(force=True)
        if len(input_json.keys()) != 5 :
            flag_invalid_json = True
        if len(input_json["user"]) < MIN_USERNAME_LEN or len(input_json["user"]) > MAX_USERNAME_LEN:
            flag_invalid_json = True
        if input_json["user"].startswith("@") or input_json["user"].endswith("@") or "." not in input_json["user"] :
            flag_invalid_json = True
        if len(input_json["password"]) < MIN_PASSWORD_LEN or len(input_json["password"]) > MAX_PASSWORD_LEN:
            flag_invalid_json = True
        if regex.search(input_json["firstname"]) != None or any(chr.isdigit() for chr in input_json["firstname"]) :
            flag_invalid_json = True
        if len(input_json["firstname"]) < MIN_ATTR_LEN or len(input_json["firstname"]) > MAX_ATTR_LEN:
            flag_invalid_json = True
        if regex.search(input_json["lastname"])  != None or any(chr.isdigit() for chr in input_json["lastname"]) :
            flag_invalid_json = True
        if len(input_json["lastname"]) < MIN_ATTR_LEN or len(input_json["lastname"]) > MAX_ATTR_LEN:
            flag_invalid_json = True
        if input_json["captcha"] != str(datetime.datetime.now().year) :
            flag_invalid_json = True
    except:
        flag_invalid_json = True

    if flag_invalid_json:
        return make_response(jsonify(message= "Invalid input json"), 400)

    try:
        connection = psycopg2.connect(user = db_username,password = db_pwd, host = db_host, port = db_port,database = db_name)
        cursor     = connection.cursor()

        # check if user already exists
        qry_userexists = "select * from "+ tbl_name + " where email='"+input_json["user"] +"';"
        cursor.execute(qry_userexists)
        totaluserfound = len(cursor.fetchall())
        if (1 == totaluserfound ):
            print("Duplicate user")
            return make_response(jsonify(message= "Duplicate user"), 400)

        useridcurrent="userid_"+str(format(LATESTUSERID, '02d'))
        LATESTUSERID+=1
        # prepare default values for fresh user
        input_json["loginstatus"]="False"
        input_json["token"]=""
        input_json["userid"]=useridcurrent

        qry_insert = "insert into " + tbl_name  + " (user_id, email, password, firstname, lastname, loginstatus, token)  values ('__USERID__','__EMAIL__','__PASSWORD__','__FIRSTNAME__','__LASTNAME__',__LOGINSTATUS__,'__TOKEN__'  );"                  
        qry_insert = qry_insert.replace("__USERID__",     input_json["userid"])
        qry_insert = qry_insert.replace("__EMAIL__",      input_json["user"])
        qry_insert = qry_insert.replace("__PASSWORD__",   input_json["password"])
        qry_insert = qry_insert.replace("__FIRSTNAME__",  input_json["firstname"])
        qry_insert = qry_insert.replace("__LASTNAME__",   input_json["lastname"])
        qry_insert = qry_insert.replace("__LOGINSTATUS__",input_json["loginstatus"])
        qry_insert = qry_insert.replace("__TOKEN__",      input_json["token"])
        # add user in db
        cursor.execute(qry_insert)
        connection.commit()
        if(1 != cursor.rowcount) :
            print ("Error while inserting query in database ", error)
            return make_response(jsonify(message= "Error while inserting query in database"), 500)
        print ("Registration success, userid=",useridcurrent)
        return make_response(jsonify(register = "Registration success", userid=useridcurrent), 201)
    except (Exception, psycopg2.Error) as error :
        print ("Error while connecting to PostgreSQL", error)
        return make_response(jsonify(message= "Error while connecting to PostgreSQL"), 500)
    finally:
        if(connection):
            cursor.close()
            connection.close()
            #print("PostgreSQL connection is closed")
        else:
            print("PostgreSQL connection is NNNNNNNNOOOOOTTTTT closed")








def v3ProcessLogin(req):
    print (str(req.get_json(force=True)))
    input_json = None
    flag_invalid_json = False
    
    # check if input json is valid
    try:
        input_json = req.get_json(force=True)
        if len(input_json.keys()) != 2 :
            flag_invalid_json = True
        if len(input_json["user"]) < MIN_USERNAME_LEN or len(input_json["user"]) > MAX_USERNAME_LEN:
            flag_invalid_json = True
        if len(input_json["password"]) < MIN_PASSWORD_LEN or len(input_json["password"]) > MAX_PASSWORD_LEN:
            flag_invalid_json = True
    except:
        flag_invalid_json = True
    
    if flag_invalid_json:
        return make_response(jsonify(message= "Invalid input json"), 400)
        
    try:
        connection = psycopg2.connect(user = db_username,password = db_pwd, host = db_host, port = db_port,database = db_name)
        cursor     = connection.cursor()

        # check if user and matching pasword exists
        qry_userexists = "select * from "+ tbl_name + " where email='__USER__' and password='__PASSWORD__';"
        qry_userexists = qry_userexists.replace("__USER__",input_json["user"])
        qry_userexists = qry_userexists.replace("__PASSWORD__",input_json["password"])
        cursor.execute(qry_userexists)
        all_records = cursor.fetchall()
        if (1 != len(all_records)):
            print("User does not exist or invalid username or password")
            return make_response(jsonify(message= "User does not exist or invalid username or password"), 400)
        
        # check if user already logged in
        if(True == all_records[0][5]):
            print("User already logged in")
            return make_response(jsonify(message= "User already logged in"), 200)

        # prepare default values
        freshtoken = getFreshToken()
        input_json["token"]=getFreshToken()
        input_json["loginstatus"]="True"

        qry_update = "update " + tbl_name  + " set loginstatus=__LOGINSTATUS__ , token='__TOKEN__' where email='__EMAIL__' ;"
        qry_update = qry_update.replace("__LOGINSTATUS__",input_json["loginstatus"])
        qry_update = qry_update.replace("__TOKEN__",      input_json["token"])
        qry_update = qry_update.replace("__EMAIL__",      input_json["user"])

        # update user login status in db
        cursor.execute(qry_update)
        connection.commit()
        if(1 != cursor.rowcount) :
            print ("Error while updating query in database ", error)
            return make_response(jsonify(message= "Error while updating query in database"), 500)

        print ("Login success, token=",freshtoken)
        return make_response(jsonify(login = "Login success", token=freshtoken), 200)
    except (Exception, psycopg2.Error) as error :
        print ("Error while connecting to PostgreSQL", error)
        return make_response(jsonify(message= "Error while connecting to PostgreSQL"), 500)
    finally:
        if(connection):
            cursor.close()
            connection.close()
            #print("PostgreSQL connection is closed")
        else:
            print("PostgreSQL connection is NNNNNNNNOOOOOTTTTT closed")
    




def v3ProcessUpdateprofile(req):
    print (str(req.get_json(force=True)))
    input_json = None
    flag_invalid_json = False
    
    # check if input json is valid
    try:
        input_json = req.get_json(force=True)
        if len(input_json.keys()) <= 2 or len(input_json.keys()) > 5 :
            flag_invalid_json = True
        if len(input_json["user"]) < MIN_USERNAME_LEN or len(input_json["user"]) > MAX_USERNAME_LEN:
            flag_invalid_json = True
        if len(input_json["password"]) < MIN_PASSWORD_LEN or len(input_json["password"]) > MAX_PASSWORD_LEN:
            flag_invalid_json = True
        if "firstname" in input_json :
            if regex.search(input_json["firstname"]) != None or any(chr.isdigit() for chr in input_json["firstname"]) :
                flag_invalid_json = True
            if len(input_json["firstname"]) < MIN_ATTR_LEN or len(input_json["firstname"]) > MAX_ATTR_LEN:
                flag_invalid_json = True
        if "lastname" in input_json:
            if regex.search(input_json["lastname"])  != None or any(chr.isdigit() for chr in input_json["lastname"]) :
                flag_invalid_json = True
            if len(input_json["lastname"]) < MIN_ATTR_LEN or len(input_json["lastname"]) > MAX_ATTR_LEN:
                flag_invalid_json = True
        if "newpassword" not in input_json:
            flag_invalid_json = True
        if len(input_json["newpassword"]) < MIN_PASSWORD_LEN or len(input_json["newpassword"]) > MAX_PASSWORD_LEN:
            flag_invalid_json = True
    except:
        flag_invalid_json = True
    
    if flag_invalid_json:
        return make_response(jsonify(message= "Invalid input json"), 400)

    try:
        connection = psycopg2.connect(user = db_username,password = db_pwd, host = db_host, port = db_port,database = db_name)
        cursor     = connection.cursor()

        # check if user and matching pasword exists
        qry_userexists = "select * from "+ tbl_name + " where email='__USER__' and password='__PASSWORD__';"
        qry_userexists = qry_userexists.replace("__USER__",input_json["user"])
        qry_userexists = qry_userexists.replace("__PASSWORD__",input_json["password"])
        cursor.execute(qry_userexists)
        all_records = cursor.fetchall()
        if (1 != len(all_records)):
            print("User does not exist or invalid username or password")
            return make_response(jsonify(message= "User does not exist or invalid username or password"), 400)
        
        # check if user already logged in
        if(False == all_records[0][5]):
            print("To update profile user needs to login first")
            return make_response(jsonify(message= "To update profile user needs to login first"), 400)

        qry_update = "update " + tbl_name  + " set password='__PASSWORD__', firstname='__FIRSTNAME__', lastname='__LASTNAME__' where email='__EMAIL__' ;"
        qry_update = qry_update.replace("__PASSWORD__", input_json["newpassword"])
        qry_update = qry_update.replace("__EMAIL__",    input_json["user"])

        if "firstname" in input_json:
            qry_update = qry_update.replace("__FIRSTNAME__",input_json["firstname"])
        else:
            qry_update = qry_update.replace(", firstname='__FIRSTNAME__'","")

        if "lastname" in input_json:
            qry_update = qry_update.replace("__LASTNAME__",input_json["lastname"])
        else:
            qry_update = qry_update.replace(", lastname='__LASTNAME__'","")

        # update user login status in db
        cursor.execute(qry_update)
        connection.commit()
        if(1 != cursor.rowcount) :
            print ("Error while updating query in database ", error)
            return make_response(jsonify(message= "Error while updating query in database"), 500)

        print ("Update profile success")
        return make_response(jsonify(updateprofile = "Update profile success"), 200)
    except (Exception, psycopg2.Error) as error :
        print ("Error while connecting to PostgreSQL", error)
        return make_response(jsonify(message= "Error while connecting to PostgreSQL"), 500)
    finally:
        if(connection):
            cursor.close()
            connection.close()
            #print("PostgreSQL connection is closed")
        else:
            print("PostgreSQL connection is NNNNNNNNOOOOOTTTTT closed")






def v3ProcessLogout(req):
    print (str(req.get_json(force=True)))
    input_json = None
    flag_invalid_json = False
    
    # check if input json is valid
    try:
        input_json = req.get_json(force=True)
        if len(input_json.keys()) != 2 :
            flag_invalid_json = True
        if len(input_json["user"]) < MIN_USERNAME_LEN or len(input_json["user"]) > MAX_USERNAME_LEN:
            flag_invalid_json = True
        if len(input_json["password"]) < MIN_PASSWORD_LEN or len(input_json["password"]) > MAX_PASSWORD_LEN:
            flag_invalid_json = True
    except:
        flag_invalid_json = True
    
    if flag_invalid_json:
        return make_response(jsonify(message= "Invalid input json"), 400)

    try:
        connection = psycopg2.connect(user = db_username,password = db_pwd, host = db_host, port = db_port,database = db_name)
        cursor     = connection.cursor()

        # check if user and matching pasword exists
        qry_userexists = "select * from "+ tbl_name + " where email='__USER__' and password='__PASSWORD__';"
        qry_userexists = qry_userexists.replace("__USER__",input_json["user"])
        qry_userexists = qry_userexists.replace("__PASSWORD__",input_json["password"])
        cursor.execute(qry_userexists)
        all_records = cursor.fetchall()
        if (1 != len(all_records)):
            print("User does not exist or invalid username or password")
            return make_response(jsonify(message= "User does not exist or invalid username or password"), 400)
        
        # check if user already logged out
        if(False == all_records[0][5]):
            print("To logout user needs to login first")
            return make_response(jsonify(message= "To logout user needs to login first"), 400)

        # prepare default values
        input_json["token"]=""
        input_json["loginstatus"]="False"

        qry_update = "update " + tbl_name  + " set loginstatus=__LOGINSTATUS__ , token='__TOKEN__' where email='__EMAIL__' ;"
        qry_update = qry_update.replace("__LOGINSTATUS__",input_json["loginstatus"])
        qry_update = qry_update.replace("__TOKEN__",      input_json["token"])
        qry_update = qry_update.replace("__EMAIL__",      input_json["user"])

        # update user login status in db
        cursor.execute(qry_update)
        connection.commit()
        if(1 != cursor.rowcount) :
            print ("Error while updating query in database ", error)
            return make_response(jsonify(message= "Error while updating query in database"), 500)

        print ("Logout success")
        return make_response(jsonify(login = "Logout success"), 200)
    except (Exception, psycopg2.Error) as error :
        print ("Error while connecting to PostgreSQL", error)
        return make_response(jsonify(message= "Error while connecting to PostgreSQL"), 500)
    finally:
        if(connection):
            cursor.close()
            connection.close()
            #print("PostgreSQL connection is closed")
        else:
            print("PostgreSQL connection is NNNNNNNNOOOOOTTTTT closed")





def v3ProcessGetaccount(req):
    flag_invalid_params = False
    user = None
    password = None

    # check if input json is valid
    try:
        user     = request.args.get('user',     default = None, type = str)
        if not user :
            flag_invalid_params = True
    except:
        flag_invalid_params = True
    
    if flag_invalid_params:
        return make_response(jsonify(message= "Invalid input params in get request"), 400)
        
    try:
        connection = psycopg2.connect(user = db_username,password = db_pwd, host = db_host, port = db_port,database = db_name)
        cursor     = connection.cursor()

        # check if user exists
        qry_userexists = "select * from "+ tbl_name + " where email='__USER__';"
        qry_userexists = qry_userexists.replace("__USER__",request.args.get('user'))
        print(qry_userexists)
        cursor.execute(qry_userexists)
        all_records = cursor.fetchall()
        if (1 != len(all_records)):
            print("User does not exist or invalid username")
            return make_response(jsonify(message= "User does not exist or invalid username"), 400)

        accountdict={'user_id':all_records[0][0],    'user':all_records[0][1],'password':all_records[0][2],
                     'firstname':all_records[0][3],  'lastname':all_records[0][4],
                     'loginstatus':all_records[0][5],'token':all_records[0][6]}
        print ("Getaccount success ",accountdict)
        return make_response(jsonify(getaccount = "Getaccount success", account=accountdict), 200)
    except (Exception, psycopg2.Error) as error :
        print ("Error while connecting to PostgreSQL", error)
        return make_response(jsonify(message= "Error while connecting to PostgreSQL"), 500)
    finally:
        if(connection):
            cursor.close()
            connection.close()
            #print("PostgreSQL connection is closed")
        else:
            print("PostgreSQL connection is NNNNNNNNOOOOOTTTTT closed")
    

