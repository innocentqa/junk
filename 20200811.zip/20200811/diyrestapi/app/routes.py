from flask import Flask,request, make_response, render_template, jsonify, make_response
from app import app
from functools import wraps
from app.helper_1 import file_ops
from app.helper_2 import file_check
from app.v1Register import *

ALL_HTTP_METHODS    = ['GET', 'HEAD', 'POST', 'PUT', 'DELETE', 'CONNECT', 'OPTIONS', 'TRACE', 'PATCH']
COMMON_HTTP_METHODS = ['GET','PUT','POST','DELETE']
BASIC_AUTH_USERNAME = 'diyuser'
BASIC_AUTH_PASSWORD = 'diypwd'
MSG_AUTH_INVALID_OR_NOTPROVIDED = "No or invalid basic auth param"
RESPONSE_ALIEN      = "Only alien uses _METHOD_ method ! Go back to your place !"

def my_auth_required(f):
    @wraps(f)
    def my_auth_decorators(*args, **kwargs):
        my_auth = request.authorization
        if my_auth and my_auth.username==BASIC_AUTH_USERNAME and my_auth.password==BASIC_AUTH_PASSWORD:
            return f(*args, **kwargs)
        else:
            return make_response(MSG_AUTH_INVALID_OR_NOTPROVIDED, 401, {'WWW-Authenticate' : 'Basic realm="No or invalid basic auth param provided"  '  } )
        
    return my_auth_decorators    



####################################################################################
# version 0 - base endpoint      / or /home
####################################################################################
@app.route('/',     methods=ALL_HTTP_METHODS)
@app.route('/home', methods=ALL_HTTP_METHODS)
def home():
    if request.method in COMMON_HTTP_METHODS:
        return make_response(render_template('documentation.html'), 200)
    else :
        return make_response(jsonify(message=RESPONSE_ALIEN.replace("_METHOD_", request.method )), 400)


@app.route('/favicon.ico') 
def favicon(): 
    return ("",200)


####################################################################################
# versio 1 - basic enpoints
####################################################################################

@app.route('/v1/register', methods=ALL_HTTP_METHODS)
def v1_register():
    if request.method != 'POST':
        return make_response(jsonify(message=RESPONSE_ALIEN.replace("_METHOD_", request.method )), 400)
    return v1ProcessRegistration(request)


@app.route('/v1/login', methods=ALL_HTTP_METHODS)
def v1_login():
    if request.method != 'POST':
        return make_response(jsonify(message=RESPONSE_ALIEN.replace("_METHOD_", request.method )), 400)
    return v1ProcessLogin(request)


@app.route('/v1/changepassword', methods=ALL_HTTP_METHODS)
def v1_changepassword():
    if request.method != 'PUT':
        return make_response(jsonify(message=RESPONSE_ALIEN.replace("_METHOD_", request.method )), 400)
    return v1ChangePassword(request)


@app.route('/v1/logout', methods=ALL_HTTP_METHODS)
def v1_logout():
    if request.method != 'POST':
        return make_response(jsonify(message=RESPONSE_ALIEN.replace("_METHOD_", request.method )), 400)
    return v1ProcessLogout(request)



    #user = request.args.get('user', default = "", type = str)
    #pwd  = request.args.get('pwd',  default = "", type = str)
    #print (user)
    #print (pwd)
    #if not user or not pwd:
    #    return "invalid username or pwd"



@app.route('/auth_check')
@my_auth_required
def auth_check():
    return "auth is tested"


@app.route('/auth_check_again')
@my_auth_required
def auth_check_again():
    return "auth is tested again"



@app.route('/search', methods=['GET'])
def search_url_parameters():
    print(' search_item=' , request.args.get('search_item', default = '---', type = str)  )
    print(' search_item_qty=' , request.args.get('search_item_qty', default = 1, type = int)   )
    return "search was called "

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'GET':
        print ('/login api called GET')
    if request.method == 'POST':
        print ('/login api called POST')
    return "/login api called123"

@app.route('/v2/check', methods=['GET', 'POST'])
def v2_check():
    if request.method == 'GET':
        print ('/v2/check api called GET')
    if request.method == 'POST':
        print ('/v2/check api called POST')
    return "/v2/check api called123"



if __name__ == '__main__':
    app.run()

